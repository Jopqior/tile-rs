# tile-rs codegen backend — prebuilt (aarch64-apple-darwin)

Prebuilt Rust→MLIR codegen backend. Mark kernels with `#[tile_std::tile_kernel]`,
pick a target with `TILERS_CODEGEN_PATH` (metal/cuda/vulkan/cpp/pto/nki/aie/bang/
gaudi/musa), and point rustc at the backend via the bundled `.cargo/config.toml`
or `TILERS_CODEGEN_SO=$PWD/lib/librustc_codegen_tile.dylib`.

ABI-pinned to nightly-2025-08-04 (rustc 1.91.0-nightly f34ba774c). Install:
  rustup toolchain install nightly-2025-08-04 --component rustc-dev --component llvm-tools --component rust-src
LLVM/MLIR 20 is bundled (@loader_path) — no `brew install llvm@20` needed at runtime.
